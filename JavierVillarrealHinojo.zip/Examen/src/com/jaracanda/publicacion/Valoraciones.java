package com.jaracanda.publicacion;

public enum Valoraciones {
	MUYBUENA,NORMAL,MUYMALA;
	
	Valoraciones(){
		
	}
}
