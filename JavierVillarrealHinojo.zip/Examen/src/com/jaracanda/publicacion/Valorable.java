package com.jaracanda.publicacion;

public interface Valorable {
	public boolean valorar(String texto);
}
