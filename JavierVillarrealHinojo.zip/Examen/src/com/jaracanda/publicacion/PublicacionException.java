package com.jaracanda.publicacion;

public class PublicacionException extends RuntimeException {
	public PublicacionException() {
		
	}
	
	public PublicacionException(String error,Throwable lanzamiento, boolean a,boolean b) {
		
	}
	public PublicacionException(String error,Throwable lanzamiento) {
		
	}
	public PublicacionException(String error) {
		
	}
	public PublicacionException(Throwable lanzamiento) {
		
	}
}
