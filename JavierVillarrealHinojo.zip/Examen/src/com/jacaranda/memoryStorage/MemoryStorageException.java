package com.jacaranda.memoryStorage;

public class MemoryStorageException extends RuntimeException {
	public MemoryStorageException() {
		
	}
	
	public MemoryStorageException(String error,Throwable lanzamiento, boolean a,boolean b) {
		
	}
	public MemoryStorageException(String error,Throwable lanzamiento) {
		
	}
	public MemoryStorageException(String error) {
		
	}
	public MemoryStorageException(Throwable lanzamiento) {
		
	}
}
